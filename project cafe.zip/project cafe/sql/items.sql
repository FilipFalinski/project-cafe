CREATE TABLE `cafe`.`items` (
  idItems INT(11) NOT NULL AUTO_INCREMENT,
  name VARCHAR(45) NOT NULL,
  category VARCHAR(45) NOT NULL,
  price VARCHAR(45) NOT NULL,
  PRIMARY KEY (`idItems`));
  

  INSERT INTO items
  (name,category,price)
  values('oat cookie','biscuit','0.40');
  
  SELECT * FROM items
 

  