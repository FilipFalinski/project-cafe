﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace cafe_coffee.user_controls
{
    public partial class UC_welcome : UserControl
    {
        public UC_welcome()
        {
            InitializeComponent();
        }
        int num = 0;

        private void timer1_Tick(object sender, EventArgs e)
        {
            if(num == 0)
            {
                lblBanner.Location = new Point(170, 308);
                lblBanner.ForeColor = Color.DarkCyan;
                num++;
            }
            else if (num == 1)
            {
                lblBanner.Location = new Point(167, 374);
                lblBanner.ForeColor = Color.White;
                num= 0;
            }
           // else if (num == 2)
           // {
           //     lblBanner.Location = new Point(173, 411);
           //     lblBanner.ForeColor = Color.DarkCyan;
           //     num = 0;
//}
        }

        private void UC_welcome_Load(object sender, EventArgs e)
        {
            timer1.Start();
        }
    }
}
